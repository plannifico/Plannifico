java -cp "lib/*" -Djava.util.logging.config.file=conf/logging.properties org.plannifico.server.PlannificoRESTListener conf/plannifico-server.xml
