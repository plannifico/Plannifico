java -cp lib/h2*.jar org.h2.tools.RunScript -url jdbc:h2:~/SalesUniverse -user "sa" -script demo/create_demo_db.sql
