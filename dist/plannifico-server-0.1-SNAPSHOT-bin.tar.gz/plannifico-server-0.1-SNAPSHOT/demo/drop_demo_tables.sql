drop table MEASURE_SET_SALES;
drop table DIM_ACCOUNT;
drop table DIM_PROVINCE;
drop table DIM_PRODUCT;
drop table DIM_SCENARIO;
drop table DIM_PERIOD;